import util/namedParameters util/type

namespace oo/type
## Awaiting pull requests for this one!

integer.=() {
  [string] value

  this="$value"

  @return
}

Type::InitializePrimitive integer
