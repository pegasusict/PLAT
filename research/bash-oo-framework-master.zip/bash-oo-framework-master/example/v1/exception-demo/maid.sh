callTheMaid(){
    [string] maid

    [[ $maid == "Steven, The Robot" ]] || throw "We don't use real maids!"
}