import maid


prepareTheCastle()
{
    true dance!
    makeTheRoom 'nice&clean'
}

makeTheRoom() {
    false || false
    echo $(callTheMaid "Franka" && bring VacuumCleaner)
}