#!/usr/bin/env bash

## BOOTSTRAP ##
source "$( cd "${BASH_SOURCE[0]%/*}" && pwd )/lib/oo-bootstrap.sh"

## MAIN ##
# import util/log util/exception util/tryCatch util/namedParameters util/class

## YOUR CODE GOES HERE ##
