[[ "${BASH_VERSINFO[0]}" -lt 4 ]] && echo "The module you are trying to load requires bash >= 4" && exit 1 || true
