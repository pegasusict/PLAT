func() {
  local wtf
  echo test
  local
  declare --p
}
func

#trap
# trap '_Dbg_debug_trap_handler 0 "$BASH_COMMAND" "$@"; func' DEBUG
# echo mama
#
# echo lol
# echo works

# echo test
# echo test2
# echo test3
# trap
# trap 'echo TEST' DEBUG
# echo LALALA
# trap - DEBUG
# echo will it work?
# echo yes?
