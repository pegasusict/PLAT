#!/usr/bin/env bash
SCRIPT_DIR=${BASH_SOURCE[0]%/*}

# load our module system:
source "${SCRIPT_DIR}/module.sh"

# below command imports module ./greeter.sh and run its 'greet' function with the following arguments:
module greeter greet tterranigma
module greeter greet niieani
