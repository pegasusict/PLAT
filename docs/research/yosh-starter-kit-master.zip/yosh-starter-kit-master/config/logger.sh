declare -A LOGGING
    LOGGING['file':'method']="file"
    LOGGING['file':'tag']="log"
