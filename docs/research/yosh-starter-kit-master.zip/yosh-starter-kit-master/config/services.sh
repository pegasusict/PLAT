logger="log-to-rsyslog"
sessionPath="tmp"
