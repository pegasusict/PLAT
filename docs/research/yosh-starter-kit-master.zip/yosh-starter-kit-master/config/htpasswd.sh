htpasswd_file="${DOCUMENT_ROOT%/}/../config/htpasswd"
