ldap_host="localhost"
ldap_port="389"
ldap_organization_name="Applications accounts"
ldap_domain_component="yosh"
