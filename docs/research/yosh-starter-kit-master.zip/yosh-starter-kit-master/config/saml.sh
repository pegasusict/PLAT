_saml_host_url="HOST"
_saml_xml_template="/var/tmp/esm/config/saml/template/auth.xml"
_saml_idp_xml="/var/tmp/esm/config/saml/idp/idp.xml"
_saml_priv_key="/var/tmp/esm/config/saml/keys/private.key"
