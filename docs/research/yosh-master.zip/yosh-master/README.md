# YOSH (Yoctu Shell) - Bash Micro Web Framework lib

This is only a lib for yoctu-starter-kit

you can git clone the repository or simply do :
```
wget -qO - https://goten.yoctu.com/archive.key | sudo apt-key add -
sudo add-apt-repository "deb https://goten.yoctu.com/ all stable"
sudo apt-get update
sudo apt-get install yosh
```

