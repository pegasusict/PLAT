# Contributing

## Commits

Write a [good commit message][commit].

## Use the test suite

To run the tests, make sure [bats](https://github.com/sstephenson/bats) is
installed and run:

```
make
```

[commit]: http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html

